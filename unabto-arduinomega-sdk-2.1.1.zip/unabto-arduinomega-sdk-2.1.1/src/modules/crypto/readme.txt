This crypto implementation of aes and sha256 is supposed to be generic across platforms.
But it also means it's slower than code optimized for e.g. 32bit platforms or 8bit platforms.
