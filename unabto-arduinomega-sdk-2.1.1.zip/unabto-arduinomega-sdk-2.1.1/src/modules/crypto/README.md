Generic crypto
==============

This module implements encryption routines which can run on many
devices.

If this code is used in a platform the encryption function on the
platform has to be tested. Tests for this code is in the
test/modules/crypto/generic folder.

Test Level
----------
This code is not tested for each release.
