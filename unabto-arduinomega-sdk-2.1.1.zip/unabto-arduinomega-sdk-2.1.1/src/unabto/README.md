uNabto Core
===========

The uNabto core is a set of functionality which is needed for all
uNabto products. The core does not contain platform specific
code. Platform specific functions have been defined in the
unabto_external_environment.h header file.


Test Level
----------

This code is tested for each release.
